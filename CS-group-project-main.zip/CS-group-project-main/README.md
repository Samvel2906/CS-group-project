# CS-group-project
Monopoly 
1) 1st class for players. They will take property, budget and player number as parameters in their constructors.
2) 2nd class will be for the dices. It will generate two random numbers for both of the dices, and if they are equal the player will be able to go again
3) 3rd class will be for the spaces on the board. Theye will be different types, and based on the types they will take different parameters.
4) 4th class will be for the board. It will have 40 spaces with different types. they will be numerated and placed in order.
5) And I think maybe we will make one for the bank.

6) For GUI several websites were used to help me write code without differences
https://www.geeksforgeeks.org/java/
https://www.youtube.com/watch?v=Kmgo00avvEw
https://docs.oracle.com/javase/tutorial/


