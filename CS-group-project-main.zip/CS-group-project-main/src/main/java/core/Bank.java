package core;

public class Bank{

}
